
let cart = [];
function addToCart(product, price) {
  cart.push({ product, price });
  updateCart();
}
function updateCart() {
  const cartItems = document.getElementById("cart-items");
  const total = document.getElementById("total");
  const checkout = document.getElementById("checkout");
  cartItems.innerHTML = "";
  let sum = 0;
  cart.forEach(item => {
    sum += item.price;
    const li = document.createElement("li");
    li.textContent = item.product + " - ₦" + item.price.toLocaleString();
    cartItems.appendChild(li);
  });
  total.textContent = "Total: ₦" + sum.toLocaleString();
  const message = encodeURIComponent("Hello, I want to buy:\n" + cart.map(i => `- ${i.product}: ₦${i.price.toLocaleString()}`).join("\n") + `\nTotal: ₦${sum.toLocaleString()}`);
  checkout.href = "https://wa.me/2348030834557?text=" + message;
}
